import { Sequelize } from 'sequelize';
import db from '../config/database.js';
import Computer from './computer.js';

const {DataTypes} = Sequelize;

const User = db.define('user',{
    user_id:{
        type: DataTypes.STRING,
        primaryKey: true,
    },
    nama: DataTypes.STRING,
    nik: DataTypes.STRING
},{
    freezeTableName:true
});

User.hasOne(Computer,{
    foreignKey:'user_id',
    onDelete:'CASCADE',
    onUpdate:'CASCADE'
});
Computer.belongsTo(User,{foreignKey:'user_id'});

export default User;