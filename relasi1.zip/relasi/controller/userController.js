import Computer from "../model/computer.js";
import User from "../model/user.js";


export const getUser = async(req, res)=>{
    try {
        const user = await User.findAll();
        res.json(user)
    } catch (error) {
        console.log(error);
    }
}

export const getUserById = async(req, res)=>{
    try {
        const user = await User.findOne({
            where:{
                user_id: req.params.id
            },include:{
                model: Computer,
                attributes: ['nama_computer']
            }
        });
        res.json(user);
    } catch (error) {
        console.log(error);
    }
}

export const createUser = async(req, res)=>{
    const nama = req.body.nama;
    const nik = req.body.nik;
    const user_id = req.body.user_id;

    try {
        await User.create({nama: nama, nik: nik, user_id: user_id});
        res.status(201).json({msg:"User ditambahkan"})
    } catch (error) {
        console.log(error)
    }
}

export const updateUser = async(req, res)=>{
    const nama = req.body.nama;
    const nik = req.body.nik;
    const user_id = req.body.user_id;

    try {
        await User.update({nama: nama, nik: nik, user_id: user_id}, {where:{ id: req.params.id
         }});
        res.status(201).json({msg:"User ditambahkan"})
    } catch (error) {
        console.log(error)
    }
}

export const deleteUser = async(req, res)=>{
    try {
        await User.destroy({where:{user_id: req.params.id}});
        res.status(201).json({msg:"User dihapus"})
    } catch (error) {
        console.log(error)
    }
}