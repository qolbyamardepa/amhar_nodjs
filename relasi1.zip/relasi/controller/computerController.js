import Computer from "../model/computer.js";

export const getComputer = async(req, res)=>{
    try {
        const computer = await Computer.findAll();
        res.json(computer)
    } catch (error) {
        console.log(error);
    }
}

export const getComputerById = async(req, res)=>{
    try {
        const computer = await Computer.findOne({where:{id: req.params.id}});
        res.json(computer);
    } catch (error) {
        console.log(error);
    }
}

export const createComputer = async(req, res)=>{
    const nama_computer = req.body.nama;
    const user_id = req.body.user_id

    try {
        await Computer.create({nama_computer: nama_computer, user_id: user_id});
        res.status(201).json({msg:"Computer ditambahkan"})
    } catch (error) {
        console.log(error)
    }
};

export const giveComputer = async(req, res)=>{
    const computer = await Computer.findOne({where:{id: req.params.id}});
    if(!computer) return res.status(404).json({msg: "Computer tidak ada"})
    const user_id = req.body.user_id

    try {
        await Computer.update({user_id: user_id}, {where:{id: req.params.id}});
        res.status(201).json({msg:"Hak akses computer diberikan"})
    } catch (error) {
        console.log(error)
    }
}


export const deleteComputer = async(req, res)=>{
    const computer = await Computer.findOne({where: {id: req.params.id}});

    if(!computer) return res.status(404).json({msg:"Computer tidak ada"});

    try {
        await Computer.destroy({where:{id: req.params.id}});
        res.status(201).json({msg: "Computer dihapus"})
    } catch (error) {
        console.log(error);
    }
}

