import express from 'express';
import { getComputer, getComputerById, createComputer, deleteComputer, giveComputer } from '../controller/computerController.js';
import { getUser, createUser, getUserById, deleteUser } from '../controller/userController.js';

const router = express.Router();

router.get('/computer', getComputer);
router.get('/computer/:id', getComputerById);
router.post('/computer', createComputer);
router.delete('/computer/:id', deleteComputer);
router.patch('/giveCom/:id', giveComputer);

router.get('/user', getUser);
router.post('/user', createUser);
router.get('/user/:id', getUserById);
router.delete('/user/:id', deleteUser);

export default router;