import { Sequelize } from "sequelize";

const db = new Sequelize('relasi_ath', 'root','',{
    host:"localhost",
    dialect: 'mysql'
});

export default db;