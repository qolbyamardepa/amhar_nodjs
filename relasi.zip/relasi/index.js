import express from "express";
import db from "./config/database.js";
import cors from 'cors';
import router from "./routes/route.js";
import fileUpload from "express-fileupload";
import User from "./model/user.js";
import Computer from "./model/computer.js";
import Departement from "./model/departement.js";
import Project from "./model/project.js";
import DeptProj from "./model/deptproj.js";

const app = express();

try {
    await db.authenticate();
    console.log("database connected");
    Computer.sync();
    User.sync();
    Departement.sync();
    Project.sync();
    DeptProj.sync();
} catch (error) {
    console.log(error);
}

app.use(cors());
app.use(express.json());
app.use(fileUpload());
app.use(router);

app.listen(5000,()=>console.log('Server On'));